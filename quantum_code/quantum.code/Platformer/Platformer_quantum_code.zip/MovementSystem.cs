﻿using Photon.Deterministic;
using Quantum.Core;
using Quantum.Physics3D;

namespace Quantum.Platformer
{
    //before: computer raw at begining > frame behind
    // 1. platform moves 2.  follow platform 3.compute raw movement  4. move and jump
    
    
    //now: sinking into platform when jump
    
    // when we platform > set kcc velocity
    // Don't use kcc velocity
    
    // XYZ velocity Y (XZ configurable)

    public unsafe class MovementSystem : SystemMainThreadFilter<MovementSystem.Filter>
    {
        public struct Filter
        {
            public EntityRef Entity;
            public Transform3D* Transform3D;
            public CharacterController3D* CharacterController;
            public PlayerPlatformController* PlatformController;
        }

        public static EntityRef GetCurrentPlatform(Frame f, Filter filter)
        {
            FPVector3 ccPosition = filter.Transform3D->Position;
            FPVector3 origin     = new FPVector3(ccPosition.X, ccPosition.Y + FP._0_10, ccPosition.Z);
            
            Draw.Line(origin, new FPVector3(origin.X, origin.Y - FP._0_20, origin.Z), ColorRGBA.Cyan);

            const QueryOptions options = QueryOptions.HitAll | QueryOptions.ComputeDetailedInfo;
            
            Hit3D? hit3D = f.Physics3D.Raycast(origin, FPVector3.Down, FP._1,  options: options);

            if (hit3D.HasValue)
            {
                if(f.Unsafe.TryGetPointer(hit3D.Value.Entity, out Platform* platform))
                {
                    return hit3D.Value.Entity;
                    //filter.Transform3D->Position = platform->Delta += ccPosition;
                }
            }

            return default;
            // var hits = f.Physics3D.Raycast(filter.Transform3D->Position /*- FPVector3.Down * FP._0_25*/, FPVector3.Down, FP._0_10, -1);
            // if (hits.HasValue && f.Unsafe.TryGetPointer<Platform>(hits.Value.Entity, out Platform* platform))
            // {
            //     return hits.Value.Entity;
            // }
            //
            // return default;
        }
        
        public override void Update(Frame f, ref Filter filter)
        {
            Input input = default;

            if (f.Unsafe.TryGetPointer(filter.Entity, out PlayerLink* playerLink))
            {
                input = *f.GetPlayerInput(playerLink->Player);
            }

            FPVector3 direction = input.Direction.XOY;

            // the problem: 
            // follow platform uses last frames callback result,
            // but ComputeRawMovement doesn't provide accurate results

            // reset before next collision
            //bool lastFrameCollision = filter.PlatformController->CollidingWithPlatform;

            filter.PlatformController->CollidingWithPlatform = false;
            var platform = GetCurrentPlatform(f, filter);
            if (platform.IsValid)
            {
                
                //filter.PlatformController->PlatformRotation = platform->RotationDelta;

                filter.PlatformController->PlatformPosition = f.Get<Transform3D>(platform).Position;

                filter.PlatformController->CollidingWithPlatform = true;
                filter.PlatformController->LastFrameCollidingWithPlatform = f.Number;
                filter.PlatformController->Platform = platform;
            }
            
            // if we are colliding with a platform this frame
            if (filter.PlatformController->CollidingWithPlatform)
            {
                FollowPlatform(f, filter);
            }
            else
            {
                // if (filter.PlatformController->Platform.IsValid)
                // {
                //     filter.Transform3D->Position += f.Unsafe.GetPointer<Platform>(filter.PlatformController->Platform)->Delta;
                // }
                //filter.Transform3D->Position += filter.PlatformController->PlatformVelocity;
            }
            
            //CharacterController3D.ComputeRawMovement(f, filter.Entity, filter.Transform3D, filter.CharacterController, direction, this);
            

            
            // move
            // CollidingWithPlatform will be set to true if we collided this frame
 
            filter.CharacterController->Move(f, filter.Entity, direction);
            //filter.Transform3D->Position += direction * f.DeltaTime * 3;

            // note: pointer property access via -> instead of .
            if (input.Jump.WasPressed)
            {
                //filter.Transform3D->Position += FPVector3.Up * 2; 
                filter.CharacterController->Jump(f);
            }
            
  
            // else if (lastFrameCollision)
            // {
            //     filter.CharacterController->Velocity += filter.PlatformController->PlatformVelocity;
            //
            //     //position = position + (position - lastPosition) + velocity * dt + impulse * dt * dt;
            // }

            // look at the direction we are moving
            if (direction != default)
                filter.Transform3D->Rotation = FPQuaternion.LookRotation(direction);
        }

        private static void FollowPlatform(Frame f, Filter filter)
        {
            // apply platform velocity
            filter.Transform3D->Position += f.Unsafe.GetPointer<Platform>(filter.PlatformController->Platform)->Delta;//filter.PlatformController->PlatformVelocity;

            // // apply platform rotation
            // FPVector3    platformPivot    = filter.PlatformController->PlatformPosition;
            // FPQuaternion platformRotation = filter.PlatformController->PlatformRotation;
            //
            // filter.Transform3D->Position =
            //     platformRotation * (filter.Transform3D->Position - platformPivot) +
            //     platformPivot;
            //
            // filter.Transform3D->Rotation =
            //     platformRotation * filter.Transform3D->Rotation;
        }

        // public bool OnCharacterCollision3D(FrameBase f, EntityRef character, Hit3D hit)
        // {
        //     PlayerPlatformController* controller = f.Unsafe.GetPointer<PlayerPlatformController>(character);
        //
        //     if (f.Unsafe.TryGetPointer(hit.Entity, out Platform* platform))
        //     {
        //         Transform3D* transform3D = f.Unsafe.GetPointer<Transform3D>(character);
        //
        //         CharacterController3D* kcc = f.Unsafe.GetPointer<CharacterController3D>(character);
        //
        //         CharacterController3DConfig config = f.FindAsset(kcc->Config);
        //
        //         FPVector3 contactToCenter = (transform3D->Position + config.Offset - hit.Point).Normalized;
        //
        //         FP angle = FPVector3.Angle(-config.GravityNormalized, contactToCenter);
        //
        //         // true = ground
        //         if (angle <= config.MaxSlope)
        //         {
        //             //controller->PlatformVelocity = platform->Delta;
        //             controller->PlatformRotation = platform->RotationDelta;
        //
        //             controller->PlatformPosition = f.Get<Transform3D>(hit.Entity).Position;
        //
        //             controller->CollidingWithPlatform = true;
        //             controller->LastFrameCollidingWithPlatform = f.Number;
        //             controller->Platform = hit.Entity;
        //         }
        //     }
        //
        //     return true;
        // }

        public void OnCharacterTrigger3D(FrameBase f, EntityRef character, Hit3D hit)
        {
        }
    }
}