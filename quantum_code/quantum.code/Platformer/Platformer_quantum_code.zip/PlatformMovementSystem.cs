﻿using Photon.Deterministic;

namespace Quantum.Platformer
{
    public unsafe class PlatformMovementSystem : SystemMainThreadFilter<PlatformMovementSystem.Filter>
    {
        public struct Filter
        {
            public EntityRef Entity;
            public Platform* Platform;
            public Transform3D* Transform3D;
        }

        public override void Update(Frame f, ref Filter filter)
        {
            FP time = filter.Platform->AccumulatedTime;

            PlatformConfig   config = f.FindAsset<PlatformConfig>(filter.Platform->Config.Id);
            FPAnimationCurve curve  = config.MovementCurve;

            FP result = curve.Evaluate(time) * config.MovementAmplitude;

            switch (config.Axis)
            {
                case PlatformAxis.X:
                    filter.Transform3D->Position.X += result;
                    break;
                case PlatformAxis.Y:
                    filter.Transform3D->Position.Y += result;
                    break;
            }

            filter.Platform->Delta =
                filter.Transform3D->Position - filter.Platform->PreviousPosition;

            filter.Platform->PreviousPosition = filter.Transform3D->Position;
        }
    }
}