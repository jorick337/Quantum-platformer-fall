﻿using Photon.Deterministic;

namespace Quantum.Platformer
{
    public unsafe class PlatformRotationSystem : SystemMainThreadFilter<PlatformRotationSystem.Filter>
    {
        public struct Filter
        {
            public EntityRef Entity;
            public Platform* Platform;
            public Transform3D* Transform3D;
        }

        public override void Update(Frame f, ref Filter filter)
        {
            FP time = filter.Platform->AccumulatedTime;

            PlatformConfig   config = f.FindAsset<PlatformConfig>(filter.Platform->Config.Id);
            FPAnimationCurve curve  = config.RotationCurve;
            
            FP result = curve.Evaluate(time) * config.RotationAmplitude;

            FPVector3 eulerAngles = filter.Transform3D->Rotation.AsEuler;
            filter.Transform3D->Rotation = FPQuaternion.Euler(eulerAngles.X, eulerAngles.Y + result, eulerAngles.Z);
            
            FPQuaternion rotationDelta = filter.Transform3D->Rotation * FPQuaternion.Inverse(filter.Platform->PreviousRotation);

            filter.Platform->RotationDelta    = rotationDelta;
            filter.Platform->PreviousRotation = filter.Transform3D->Rotation;
        }
    }
}