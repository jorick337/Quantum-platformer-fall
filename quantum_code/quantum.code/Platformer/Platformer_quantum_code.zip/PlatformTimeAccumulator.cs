﻿namespace Quantum.Platformer
{
    public unsafe class PlatformTimeAccumulator : SystemMainThreadFilter<PlatformTimeAccumulator.Filter>
    {
        public struct Filter
        {
            public EntityRef Entity;
            public Platform* Platform;
        }

        public override void Update(Frame f, ref Filter filter)
        {
            filter.Platform->AccumulatedTime += f.DeltaTime;
        }
    }
}