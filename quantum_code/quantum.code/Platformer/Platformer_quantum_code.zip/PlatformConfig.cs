﻿using Photon.Deterministic;

namespace Quantum
{
    public enum PlatformAxis
    {
        X,
        Y,
    }
    
    partial class PlatformConfig
    {
        public FP MovementAmplitude;
        public FP RotationAmplitude;
        
        public PlatformAxis Axis;
        public FPAnimationCurve MovementCurve;
        public FPAnimationCurve RotationCurve;
    }
}