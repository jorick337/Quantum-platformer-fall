﻿using Photon.Deterministic;

namespace Quantum.Platformer
{
    public unsafe class AddPlatformInertiaSystem : SystemMainThreadFilter<AddPlatformInertiaSystem.Filter>
    {
        private readonly FP _drag = FP._0_05;
        
        public struct Filter
        {
            public EntityRef EntityRef;
            public PlayerPlatformController* PlayerPlatformController;
        }

        public override void Update(Frame f, ref Filter filter)
        {
            var dif = f.Number - filter.PlayerPlatformController->LastFrameCollidingWithPlatform;
            if (dif > 10)
            { 
                //filter.PlayerPlatformController->PlatformVelocity *= (1 - _drag) * f.DeltaTime;
            }
        }
    }
}